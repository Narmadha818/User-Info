﻿using UserInfo.Models.BaseModels;

namespace UserInfo.Models
{
    public class UserModel : UserBase
    {
        public StateModel? State { get; set; }
    }
}