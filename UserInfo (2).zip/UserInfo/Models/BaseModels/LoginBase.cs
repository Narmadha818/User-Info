﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace UserInfo.Models.BaseModels
{
    public class LoginBase : Auditable
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("username")]
        public string UserName { get; set; }

        [Column("password")]
        public string Password { get; set; }

        [Column("refreshtoken")]
        public string? RefreshToken { get; set; }

        [Column("refreshtokenexpirytime")]
        public DateTime RefreshTokenExpiryTime { get; set; }



    }
}