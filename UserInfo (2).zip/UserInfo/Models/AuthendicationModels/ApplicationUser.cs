﻿using Microsoft.AspNetCore.Identity;
using UserInfo.Models.BaseModels;

namespace UserInfo.Models.AuthendicationModels
{
    public class ApplicationUser
    {
        public string? RefreshToken { get; set; }
        public DateTime RefreshTokenExpiryTime { get; set; }
    }
}