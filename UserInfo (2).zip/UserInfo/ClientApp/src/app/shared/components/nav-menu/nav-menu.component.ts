import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { User } from '../../models';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent implements OnInit {

  public jwtHelper: JwtHelperService = new JwtHelperService();
  isAuthenticated = false;
  loggedInUser = "";
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.isUserAuthenticated();
  }

  isUserAuthenticated() {
    const token: string | null = localStorage.getItem("accessToken");
    console.log(this.jwtHelper.isTokenExpired(token))
    if (token != null && !this.jwtHelper.isTokenExpired(token)) {
      const user: User | null = JSON.parse(localStorage.getItem('user') || "{}");
      this.isAuthenticated = true;
      this.loggedInUser = user?.firstName + " " + user?.lastName
    }
    else {
      this.isAuthenticated = false;
    }
  }

  public logOut() {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
    localStorage.removeItem("user");
    this.router.navigate(["/login"]);
  }

  public login() {
    this.router.navigate(['/login']);
  }
}
