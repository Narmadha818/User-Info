import { State } from "./state";

export class User {
    id: number =0;
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    address: string;
    stateId : number;
    country : string;
    postalCode : string;   
    state : State; 
}

