import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '@environments/environment';
import { User } from '@app/shared/models';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private userSubject: BehaviorSubject<any>;
  public user: Observable<User>;

  constructor(
    private router: Router,
    private http: HttpClient,
  ) {
    this.userSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('userData') || "{}"));
    this.user = this.userSubject.asObservable();
  }

  public get currentUserValue(): any {
    return this.userSubject.value;
  }

 addUserValue(data: any) {
   this.userSubject.next(data);
 }

  login(username, password) {
    return this.http.post<User>(`${environment.api_url}/authenticate/login`, { username, password })
      .pipe(map(user => {
        // store user details and jwt token in local storage to keep user logged in between page refreshes
        localStorage.setItem('user', JSON.stringify(user["user"]));
        const token = (<any>user).accessToken;
        const refreshToken = (<any>user).refreshToken;
        const userInfo = (<any>user).user;
        localStorage.setItem("user", JSON.stringify(userInfo));
        localStorage.setItem("userData", JSON.stringify(user));
        this.userSubject.next(user);
        return user;
      }));
  }

  logout() {
    // remove user from local storage and set current user to null
    localStorage.removeItem('user');
    this.userSubject.next(new User());
    this.router.navigate(['/login']);
  }
}
