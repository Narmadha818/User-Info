import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { ConfirmDialogComponent } from '@app/shared/components/confirm-dialog/confirm-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class DialogService {

  constructor(private dialog: MatDialog) { }

  openDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      width: '35vw',
      height: '200px',
      disableClose: false,
      autoFocus: true,
      data: { message: msg, },
      backdropClass: 'backdrop'
    });
  }
}