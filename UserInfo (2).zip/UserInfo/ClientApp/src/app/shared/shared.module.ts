import { NgModule, APP_INITIALIZER } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MaterialModule } from './material/material.module'
import { FlexLayoutModule } from "@angular/flex-layout";
import { ToastrModule } from 'ngx-toastr';
import { NgxSpinnerModule, NgxSpinnerService } from "ngx-spinner";
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from './interceptors/token.interceptor';
import { ReactiveFormsModule } from '@angular/forms';
import { LoaderComponent, NavMenuComponent, ConfirmDialogComponent } from './components';


@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    ToastrModule.forRoot({
      timeOut: 2000,
      positionClass: 'toast-top-right',
    }),
    NgxSpinnerModule,
  ],
  declarations: [NavMenuComponent, LoaderComponent, ConfirmDialogComponent],
  exports: [NavMenuComponent, LoaderComponent, ConfirmDialogComponent,
    FlexLayoutModule, MaterialModule, ToastrModule, NgxSpinnerModule],
  entryComponents: [ConfirmDialogComponent],
  providers: [NgxSpinnerService,
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true }],

})
export class SharedModule { }
