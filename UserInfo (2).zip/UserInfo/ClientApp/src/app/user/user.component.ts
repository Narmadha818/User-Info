import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { finalize } from "rxjs/operators";
import { ToastrService } from 'ngx-toastr';

import { UserService } from '@app/shared/services';
import { AddUserComponent} from './add-user/add-user.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  title = 'ClientApp';

  constructor(private router: Router, private dialog: MatDialog, private toastr: ToastrService,
    private userService: UserService,) { }

  openAddDialog(): void {
    const dialogRef = this.dialog.open(AddUserComponent, {
      width: '75vw',
      autoFocus: false
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
       // this.toastr.success("User Addes successfully.")
      }
    });
  }
}

