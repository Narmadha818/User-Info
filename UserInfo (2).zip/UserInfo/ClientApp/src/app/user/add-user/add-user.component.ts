import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { UserService } from '@app/shared/services';
import { User, State } from '@app/shared/models';
import { finalize } from "rxjs/operators";
@Component({
    selector: 'app-add-user',
    templateUrl: './add-user.component.html',
    styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
    userForm: FormGroup;
    id: string;
    isAddMode: boolean;
    loading = false;
    submitted = false;
    states: State[] = [];
    user: User = new User();
    emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
    constructor(
        private formBuilder: FormBuilder,
        private toastr: ToastrService,
        private spinner: NgxSpinnerService,
        private userService: UserService,
        public dialogRef: MatDialogRef<AddUserComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any
    ) {
        this.userService.getStates()
            .subscribe(data => {
                this.states = data;
            }, err => {
                console.log(err);
            });

        if (this.data != null)
            this.user = JSON.parse(this.data.user);
    }

    ngOnInit() {
        this.getStates();
        this.userForm = this.formBuilder.group({
            firstName: new FormControl(this.user ? this.user.firstName : '', [Validators.required]),
            lastName: new FormControl(this.user ? this.user.lastName : '', [Validators.required]),
            email: new FormControl(this.user ? this.user.email : '',[Validators.required, Validators.pattern(this.emailPattern)]),
            phoneNumber: new FormControl(this.user ? this.user.phoneNumber : '', [Validators.required]),
            address: new FormControl(this.user ? this.user.address : '', [Validators.required]),
            state: new FormControl(this.user ? this.user.stateId : 0, [Validators.required]),
            country: new FormControl(this.user ? this.user.country : '', [Validators.required]),
            postalCode: new FormControl(this.user ? this.user.postalCode : '', [Validators.required]),
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.userForm.controls; }


    getStates() {
        this.spinner.show();
        this.userService.getStates().pipe(
            finalize(() => { this.spinner.hide(); }))
            .subscribe(data => {
                this.states = data;
            }, err => {
                console.log(err);
            });
    }

    onSubmit() {
        this.submitted = true;

        if (this.userForm.invalid) {
            return;
        }

        this.loading = true;
        // if (this.isAddMode) {
        //     this.addUser();
        // } else {
        //     this.updateUser();
        // }
    }

    saveUser() {
        this.spinner.show();
        console.log(this.userForm.value);
        this.user.firstName = this.userForm.value.firstName;
        this.user.lastName = this.userForm.value.lastName;
        this.user.email = this.userForm.value.email;
        this.user.phoneNumber = this.userForm.value.phoneNumber;
        this.user.address = this.userForm.value.address;
        this.user.stateId = this.userForm.value.state;
        this.user.country = this.userForm.value.country;
        this.user.postalCode = this.userForm.value.postalCode;

        if (this.user.id > 0) {
            this.userService.updateUser(this.user)
                .pipe(finalize(() => { this.spinner.hide(); }))
                .subscribe({
                    next: () => {
                        //this.alertService.success('Update successful', { keepAfterRouteChange: true });
                        this.dialogRef.close();
                    },
                    error: error => {
                        //this.alertService.error(error);
                        this.loading = false;
                    }
                });
        }
        else {
            this.userService.addUser(this.user)
                .pipe(finalize(() => { this.spinner.hide(); }))
                .subscribe({
                    next: () => {
                        this.toastr.success("No User(s) found.")
                        this.dialogRef.close();
                    },
                    error: error => {
                        this.toastr.error("Error Occured while processing the request.")
                        this.loading = false;
                    }
                });
        }
    }

    cancel() {

    }
}
