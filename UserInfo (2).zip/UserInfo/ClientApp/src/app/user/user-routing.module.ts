import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ListUserComponent } from './list-user/list-user.component';
import { AddUserComponent } from './add-user/add-user.component'
import { UserComponent } from './user.component';

import { AuthGuard } from '@app/shared/guard/auth.guard';

const routes: Routes = [
  {
    path: '', component: UserComponent, canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
