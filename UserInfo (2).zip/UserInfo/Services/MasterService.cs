﻿using Microsoft.EntityFrameworkCore;
using UserInfo.Data;
using UserInfo.Models;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace UserInfo.Services
{
    public class MasterService : IMasterService
    {
        private readonly UserDbContext _dbContext;

        public MasterService(UserDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<StateModel>> GetStates()
        {
            try
            {
                var result = await _dbContext.States
                                    .Select(s => new StateModel() { Id = s.Id, Name = s.Name })
                                    .ToListAsync();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task AddStates()
        {
            try
            {
                var states = new List<State>();
                states.AddRange(new List<State>()
                    { new State { Name = "TamilNadu" },
                        new State { Name = "Kerala" },
                        new State { Name = "Karnataka" },
                        new State { Name = "Maharasta" }
                    });

                _dbContext.States.AddRange(states);
                await _dbContext.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }    
}
