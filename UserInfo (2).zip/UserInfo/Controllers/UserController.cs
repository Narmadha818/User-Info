﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserInfo.Models;
using UserInfo.Services;

namespace UserInfo.Controllers
{
    //[Authorize]
    [ApiController]
    [Route("api/user")]
    public class UserController : ControllerBase
    {     
        private readonly ILogger<UserController> _logger;
        private readonly IUserService _userService;

        public UserController(ILogger<UserController> logger, IUserService userService)
        {
            _logger = logger;
            _userService = userService;
        }

        [HttpGet]
        public async Task<IActionResult> GetUsers()
        {
            var users = await _userService.GetUsers();
            return Ok(users);
        }

        [HttpPost]
        public async Task<IActionResult> AddUser(UserModel userModel)
        {
            await _userService.AddUser(userModel);
            return Ok(200);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateUser(UserModel userModel)
        {
            await _userService.UpdateUser(userModel);
            return Ok(200);
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteUser(int id)
        {
            await _userService.DeleteUser(id);
            return Ok(200);
        }
    }
}
