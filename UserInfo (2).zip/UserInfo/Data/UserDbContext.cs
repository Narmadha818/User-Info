﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace UserInfo.Data
{
    public class UserDbContext : DbContext
    {
        public UserDbContext()
        {

        }

        public UserDbContext(DbContextOptions<UserDbContext> options)
            : base(options)
        {

        }

        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<State> States { get; set; }

        public virtual DbSet<Login> Logins { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
            .HasOne<State>(f => f.UserState)
             .WithMany(f => f.Users)
             .HasForeignKey(f => f.StateId);   
        }
    }
}
