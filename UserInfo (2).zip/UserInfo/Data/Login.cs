﻿using UserInfo.Models.BaseModels;

namespace UserInfo.Data
{
    public class Login : LoginBase
    {

    }
}