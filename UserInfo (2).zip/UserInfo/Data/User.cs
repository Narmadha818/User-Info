﻿using UserInfo.Models.BaseModels;

namespace UserInfo.Data
{
    public class User : UserBase
    {
        public User()
        {
        }
        public virtual State UserState { get; set; }
    }
}