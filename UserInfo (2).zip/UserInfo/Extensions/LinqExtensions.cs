﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace UserInfo.Extensions
{
    /// <summary>
    /// LinqExtensions class.
    /// </summary>
    public static class LinqExtensions
    {
        /// <summary>
        /// Adds to where clause based on property check.
        /// </summary>
        /// <typeparam name="T">entity.</typeparam>
        /// <param name="query">query.</param>
        /// <param name="condition">condition.</param>
        /// <param name="whereClause">whereClause.</param>
        /// <returns>IQueryable<typeparamref name="T"/>T.</returns>
        public static IQueryable<T> WhereIf<T>(this IQueryable<T> query, bool condition, Expression<Func<T, bool>> whereClause)
        {
            if (condition)
            {
                return query.Where(whereClause);
            }

            return query;
        }
    }
}
