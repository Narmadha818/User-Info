﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserInfo.Services;

namespace UserInfo.Controllers
{
    [ApiController]
    [Route("api/master")]
    public class MasterController : ControllerBase
    {     
        private readonly ILogger<MasterController> _logger;
        private readonly IMasterService _masterService;

        public MasterController(ILogger<MasterController> logger, IMasterService masterService)
        {
            _logger = logger;
            _masterService = masterService;
        }

        [HttpGet]
        [Route("states")]
        public async Task<IActionResult> GetStates(int id = 0)
        {
            var states = await _masterService.GetStates();
            return Ok(states);
        }

        [HttpPost]
        [Route("states")]
        public async Task<IActionResult> AddStates()
        {
            await _masterService.AddStates();
            return Ok(200);
        }
    }
}
