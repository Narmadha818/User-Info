export const environment = {
  production: true,
  api_url : '/api',
  masterContextPath: "/master",
  userContextPath: "/user",
};
