import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';
import { finalize } from "rxjs/operators";
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { User } from '@app/shared/models';
import { UserService, DialogService } from '@app/shared/services';
import { AddUserComponent } from '../add-user/add-user.component';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})


export class ListUserComponent implements OnInit {
  users: User[] = [];
  displayedColumns = ['First Name', "Last Name", 'Email', 'Phone Number', 'State', 'Actions'];
  dataSource: MatTableDataSource<User>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog,
    private router: Router,
    private dialogService: DialogService,
    private toastr: ToastrService,
    public spinner: NgxSpinnerService,
    private userService: UserService) {
    this.dataSource = new MatTableDataSource(this.users);
  }

  ngAfterViewInit() {
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }

  ngOnInit(): void {
    this.getAllUsers();
  }

  public editUser(userId: number) {
    console.log(userId)
    let user = this.users.find(u => u.id == userId);
    console.log(user)
    const dialogRef = this.dialog.open(AddUserComponent, {
      width: '75vw',
      autoFocus: false,
      data: { user: JSON.stringify(user) }
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getAllUsers();
    });
  }

  getAllUsers() {
    var userData: any = [];
    this.spinner.show();
    this.userService.getUsers().pipe(
      finalize(() => { this.spinner.hide(); }))
      .subscribe(userList => {
        if (userList) {
          if (userList.length > 0) {
            this.users = userList;
            this.users.forEach(u => {
              let source =
              {
                "Id": u.id,
                'First Name': u.firstName,
                'Last Name': u.lastName,
                "Email": u.email,
                "Phone Number": u.phoneNumber,
                "State": u.state.name
              }
              userData.push(source);
            });
            this.dataSource = new MatTableDataSource<User>(userData);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
          }
          else
            this.toastr.info("No User(s) found.")
        }
      }, (error: any) => {
        if (error && (error.status == 401 || error.status == 403)) {
          this.router.navigate(['/unauthorized']);
        }
        else if (error && error.status == 404)
          this.toastr.info("No User(s) found.")
        else
          this.toastr.error("Error Occured while processing the request.")
      });
  }

  openAddDialog(): void {
    const dialogRef = this.dialog.open(AddUserComponent, {
      width: '75vw',
      autoFocus: false
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getAllUsers();
    });
  }

  public deleteUserDialog(userId: number) {
    const text = (<any>document.getElementById("delete-dialog"));
    this.dialogService.openDialog(text.innerHTML).afterClosed()
      .subscribe((res) => {
        if (res) {
          this.spinner.show();
          this.userService.deleteUser(userId).pipe(
            finalize(() => { this.spinner.hide(); }))
            .subscribe(() => {
              this.getAllUsers();
              this.toastr.success("User deleted successfully.")
            }, (error: any) => {
              this.toastr.error("Error Occured while processing the request.")
            });
        }
      });
  }
}



