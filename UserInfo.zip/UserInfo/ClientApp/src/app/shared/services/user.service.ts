import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';

import { environment } from '@environments/environment';
import { User, State } from '../models';
import { ApiService } from './api.service';


const userContextPath = environment.userContextPath;
const masterContextPath = environment.masterContextPath;


@Injectable({
    providedIn: 'root'
})
export class UserService {

    constructor(private apiService: ApiService) {
    }
 
    getStates() {
        return this.apiService.get(`${masterContextPath}/states`)
            .pipe(map((data: State[]) => { return data; }));
    }

    getUsers() {
        return this.apiService.get(`${userContextPath}`)
            .pipe(map((data: User[]) => { return data; }));
    }

    addUser(user: User) {
        return this.apiService.post(`${userContextPath}`, user)
            .pipe(map(response => { return response.body; }));
    }

    updateUser(user: User) {
        return this.apiService.put(`${userContextPath}`, user)
            .pipe(map(response => { return response.body; }));
    }

    deleteUser(id: number) {
        return this.apiService.delete(`${userContextPath}/?id=${id}`)
            .pipe(map(response => { return response.body; }));
    }
}
