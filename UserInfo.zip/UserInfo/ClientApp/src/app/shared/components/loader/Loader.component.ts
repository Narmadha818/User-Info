import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loader',
  templateUrl: 'Loader.component.html',
  styleUrls: ['Loader.component.scss']
})
export class LoaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
