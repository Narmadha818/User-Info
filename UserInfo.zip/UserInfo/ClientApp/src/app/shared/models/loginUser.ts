import { User } from "./user";

export class LoginUser {
    user: User;
    token: string;
    RefreshToken: string;
    Expiration: string;   
}

