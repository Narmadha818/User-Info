import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavMenuComponent } from './components/nav-menu/nav-menu.component';
import { RouterModule } from '@angular/router';
import { MaterialModule } from './material/material.module'
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { FlexLayoutModule } from "@angular/flex-layout";
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from './interceptors/token.interceptor';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { SearchPipe } from './pipes/search.pipe';
import { DropdownComponent } from './components/dropdown/dropdown.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RepDialogComponent } from './components/rep-dialog/rep-dialog.component';
import { SortPipe } from './pipes/sort.pipe';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule,
    FlexLayoutModule,
    NgxMatSelectSearchModule,
    ReactiveFormsModule
  ],
  declarations: [NavMenuComponent, SidebarComponent, SearchPipe, DropdownComponent, RepDialogComponent,SortPipe],
  exports: [NavMenuComponent, SidebarComponent, FlexLayoutModule, MaterialModule, DropdownComponent, RepDialogComponent, NgxMatSelectSearchModule, SearchPipe,SortPipe],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true }]
})
export class SharedModule { }
