﻿using Microsoft.AspNetCore.Http;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Web.Http;

namespace UserInfo.Filters
{
    [ExcludeFromCodeCoverage]
    public static class SessionHelper
    {
        public static string GetUserId(IHttpContextAccessor httpContextAccessor)
        {
            if(httpContextAccessor == null)
            {
                throw new HttpResponseException(HttpStatusCode.BadRequest);    
          
            }
            return httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(x => x.Type == "externalid")?.Value;
        }
    }
}
