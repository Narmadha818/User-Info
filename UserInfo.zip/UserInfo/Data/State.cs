﻿using System.Collections.Generic;
using UserInfo.Models.BaseModels;

namespace UserInfo.Data
{
    public class State : StateBase
    {
        public State()
        {
            this.Users = new HashSet<User>();
        }
        public virtual ICollection<User> Users { get; set; }
    }
}