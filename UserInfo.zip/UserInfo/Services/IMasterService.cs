﻿using System.Collections.Generic;
using System.Threading.Tasks;
using UserInfo.Models;

namespace UserInfo.Services
{
    public interface IMasterService
    {
        Task<List<StateModel>> GetStates();

        Task AddStates();
    }
}