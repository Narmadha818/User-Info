﻿using System.Collections.Generic;
using System.Threading.Tasks;
using UserInfo.Models;
using UserInfo.Models.AuthendicationModels;

namespace UserInfo.Services
{
    public interface IUserService
    {
        Task AddUser(UserModel userModel);

        Task AddDefaultUsers();

        Task UpdateUser(UserModel userModel);

        Task<List<UserModel>> GetUsers();

        Task DeleteUser(int id);

        Task<LoginUserModel> GetLoginUser(string userName, string password = "");

        Task UpdateLoginProfile(LoginModel user);
    }
}
