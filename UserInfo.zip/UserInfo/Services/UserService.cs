﻿using Microsoft.EntityFrameworkCore;
using UserInfo.Data;
using UserInfo.Models;
using System.Net;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System;
using UserInfo.Extensions;
using System.Web.Http;
using UserInfo.Filters;
using System.Text;
using UserInfo.Models.AuthendicationModels;

namespace UserInfo.Services
{
    public class UserService : IUserService
    {
        private readonly UserDbContext _dbContext;
        private readonly IHttpContextAccessor httpContext;

        public UserService(UserDbContext dbContext, IHttpContextAccessor httpContext)
        {
            _dbContext = dbContext;
            this.httpContext = httpContext;
        }

        async Task IUserService.AddUser(UserModel userModel)
        {
            try
            {
                if (userModel?.Email.Length <= 0)
                {
                    throw new HttpResponseException(HttpStatusCode.BadRequest);
                }

                if (userModel?.PhoneNumber.Length <= 0)
                {
                    throw new HttpResponseException(HttpStatusCode.BadRequest);
                }

                var user = new User();

                user = await _dbContext.Users.Where(x => x.IsDeleted == false && 
                                                        (x.Email == userModel.Email
                                                            || x.PhoneNumber == userModel.PhoneNumber)).FirstOrDefaultAsync();       

                if (user != null)
                {
                    throw new HttpResponseException(HttpStatusCode.Conflict);
                }
                else
                {
                    user = new User
                    {
                        FirstName = userModel.FirstName,
                        LastName = userModel.LastName,
                        Email = userModel.Email.ToLower(),
                        PhoneNumber = userModel.PhoneNumber,
                        Address = userModel.Address,
                        StateId = userModel.StateId,
                        Country = userModel.Country,
                        PostalCode = userModel.PostalCode,
                        IsDeleted = false,
                        CreatedBy = SessionHelper.GetUserId(httpContext),
                        CreatedDateTime = DateTime.UtcNow
                    };

                    var userLogin = new Login
                    {
                        UserName = userModel.Email.ToLower(),
                        Password = Encryptdata("test123"),
                        
                        CreatedBy = SessionHelper.GetUserId(httpContext),
                        CreatedDateTime = DateTime.UtcNow
                    };

                    _dbContext.Users.Add(user);
                    _dbContext.Logins.Add(userLogin);

                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        async Task<List<UserModel>> IUserService.GetUsers()
        {
            try
            {
                var result = await _dbContext.Users
                                     .Where(u => u.IsDeleted == false)
                                    .Include(i => i.UserState)
                                    .Select(u => new UserModel()
                                    {
                                        Id = u.Id,
                                        FirstName = u.FirstName,
                                        LastName = u.LastName,
                                        Email = u.Email,
                                        PhoneNumber = u.PhoneNumber,
                                        Address = u.Address,
                                        StateId = u.StateId,
                                        State = new StateModel
                                        {
                                            Id = u.UserState.Id,
                                            Name = u.UserState.Name,
                                        },
                                        Country = u.Country,
                                        PostalCode = u.PostalCode,
                                        CreatedBy = u.CreatedBy,
                                        CreatedDateTime = u.CreatedDateTime,
                                        UpdatedBy = u.UpdatedBy,
                                        UpdatedDateTime = u.UpdatedDateTime
                                    }).Distinct().ToListAsync();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        async Task IUserService.UpdateUser(UserModel userModel)
        {
            try
            {
                if (userModel?.Id <= 0)
                {
                    throw new HttpResponseException(HttpStatusCode.BadRequest);
                }

                var user = new User();

                user = await _dbContext.Users.Where(x => x.Id == userModel.Id
                                && x.IsDeleted == false).FirstOrDefaultAsync();

                if (user == null)
                {
                    throw new HttpResponseException(HttpStatusCode.NotFound);
                }
                else
                {
                    user.FirstName = userModel.FirstName;
                    user.LastName = userModel.LastName;
                    user.Email = userModel.Email;
                    user.PhoneNumber = userModel.PhoneNumber;
                    user.Address = userModel.Address;
                    user.StateId = userModel.StateId;
                    user.Country = userModel.Country;
                    user.PostalCode = userModel.PostalCode;
                    user.IsDeleted = false;
                    user.UpdatedBy = SessionHelper.GetUserId(httpContext);
                    user.UpdatedDateTime = DateTime.UtcNow;

                    _dbContext.Users.Update(user);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        async Task IUserService.DeleteUser(int id)
        {
            try
            {
                if (id <= 0)
                {
                    throw new HttpResponseException(HttpStatusCode.BadRequest);
                }

                var user = await _dbContext.Users.Where(x => x.Id == id 
                                && x.IsDeleted == false).FirstOrDefaultAsync();
                if (user == null)
                {
                    throw new HttpResponseException(HttpStatusCode.NotFound);
                }
                else
                {                  
                    user.IsDeleted = true;
                    user.UpdatedBy = SessionHelper.GetUserId(httpContext);
                    user.UpdatedDateTime = DateTime.UtcNow;

                    _dbContext.Users.Update(user);
                    await _dbContext.SaveChangesAsync();
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
               
        private string Encryptdata(string password)
        {
            string encPwd = string.Empty;
            byte[] encode = new byte[password.Length];
            encode = Encoding.UTF8.GetBytes(password);
            encPwd = Convert.ToBase64String(encode);
            return encPwd;
        }

        private string Decryptdata(string encryptpwd)
        {
            string decryptpwd = string.Empty;
            UTF8Encoding encodepwd = new UTF8Encoding();
            Decoder Decode = encodepwd.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(encryptpwd);
            int charCount = Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            decryptpwd = new String(decoded_char);
            return decryptpwd;
        }

        async Task<LoginUserModel> IUserService.GetLoginUser(string userName, string password ="")
        {
            try
            {
                var isValid = false;
                var encryptpwd = string.Empty;
                if (password.Length > 0)
                {
                    encryptpwd = Encryptdata(password);
                }
                        
                var loginDetails = await _dbContext.Logins
                                   .Where(u => u.UserName == userName
                                   && (encryptpwd.Length <= 0 || 
                                   (encryptpwd.Length > 0 && u.Password == encryptpwd)))
                                   .Select(u => new LoginModel
                                   {
                                       UserName = u.UserName,
                                       Password = u.Password,
                                       RefreshToken = u.RefreshToken,
                                       RefreshTokenExpiryTime = u.RefreshTokenExpiryTime,
                                   })
                                 .FirstOrDefaultAsync();

                var userDetails = await _dbContext.Users
                                     .Where(u => u.IsDeleted == false && u.Email == userName.ToLower())
                                    .Include(i => i.UserState)
                                    .Select(u => new UserModel()
                                    {
                                        Id = u.Id,
                                        FirstName = u.FirstName,
                                        LastName = u.LastName,
                                        Email = u.Email,
                                        PhoneNumber = u.PhoneNumber,
                                        Address = u.Address,
                                        StateId = u.StateId,
                                        State = new StateModel
                                        {
                                            Id = u.UserState.Id,
                                            Name = u.UserState.Name,
                                        },
                                        Country = u.Country,
                                        PostalCode = u.PostalCode,
                                        CreatedBy = u.CreatedBy,
                                        CreatedDateTime = u.CreatedDateTime,
                                        UpdatedBy = u.UpdatedBy,
                                        UpdatedDateTime = u.UpdatedDateTime
                                    }).FirstOrDefaultAsync();

                var loginUserProfiles = new LoginUserModel
                {
                    LoginProfile = loginDetails,
                    UserProfile = userDetails,
                };

                return loginUserProfiles;
            }
            catch(Exception)
            {
                throw;
            }
        }

        async Task IUserService.UpdateLoginProfile(LoginModel user)
        {
            try
            {
                var loginUser = await _dbContext.Logins
                                    .Where(x => x.UserName == user.UserName.ToLower()).FirstOrDefaultAsync();

                if (loginUser != null)
                {
                    loginUser.RefreshToken = user.RefreshToken;
                    loginUser.RefreshTokenExpiryTime = user.RefreshTokenExpiryTime;

                    _dbContext.Logins.Update(loginUser);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task AddDefaultUsers()
        {
            try
            {
                var user = new UserModel
                {
                    FirstName = "Test User 1",
                    LastName = "Knila",
                    Email = "testuser1@knila.com",
                    PhoneNumber = "2343423456",
                    Address = "Test Address 1",
                    StateId = 1,
                    Country = "India",
                    PostalCode = "234433",
                    IsDeleted = false,
                    CreatedBy = SessionHelper.GetUserId(httpContext),
                    CreatedDateTime = DateTime.UtcNow
                };

                await AddUser(user);
                user = new UserModel
                {
                    FirstName = "Test User 2",
                    LastName = "Knila",
                    Email = "testuser2@knila.com",
                    PhoneNumber = "4543423455",
                    Address = "Test Address 2",
                    StateId = 3,
                    Country = "India",
                    PostalCode = "123434",
                    IsDeleted = false,
                    CreatedBy = SessionHelper.GetUserId(httpContext),
                    CreatedDateTime = DateTime.UtcNow
                };

                await AddUser(user);

                user = new UserModel
                {
                    FirstName = "Test User 3",
                    LastName = "Knila",
                    Email = "testuser3@knila.com",
                    PhoneNumber = "5643423455",
                    Address = "Test Address 3",
                    StateId = 3,
                    Country = "India",
                    PostalCode = "123435",
                    IsDeleted = false,
                    CreatedBy = SessionHelper.GetUserId(httpContext),
                    CreatedDateTime = DateTime.UtcNow
                };

                await AddUser(user);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task AddUser(UserModel userModel)
        {
            try
            {
                if (userModel?.Email.Length <= 0)
                {
                    throw new HttpResponseException(HttpStatusCode.BadRequest);
                }

                if (userModel?.PhoneNumber.Length <= 0)
                {
                    throw new HttpResponseException(HttpStatusCode.BadRequest);
                }

                var user = new User();

                user = await _dbContext.Users.Where(x => x.Email == userModel.Email
                                           || x.PhoneNumber == userModel.PhoneNumber).FirstOrDefaultAsync();

                if (user != null)
                {
                    throw new HttpResponseException(HttpStatusCode.Conflict);
                }
                else
                {
                    user = new User
                    {
                        FirstName = userModel.FirstName,
                        LastName = userModel.LastName,
                        Email = userModel.Email.ToLower(),
                        PhoneNumber = userModel.PhoneNumber,
                        Address = userModel.Address,
                        StateId = userModel.StateId,
                        Country = userModel.Country,
                        PostalCode = userModel.PostalCode,
                        IsDeleted = false,
                        CreatedBy = SessionHelper.GetUserId(httpContext),
                        CreatedDateTime = DateTime.UtcNow
                    };

                    var userLogin = new Login
                    {
                        UserName = userModel.Email.ToLower(),
                        Password = Encryptdata("test123"),

                        CreatedBy = SessionHelper.GetUserId(httpContext),
                        CreatedDateTime = DateTime.UtcNow
                    };

                    _dbContext.Users.Add(user);
                    _dbContext.Logins.Add(userLogin);

                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
