﻿using UserInfo.Models.BaseModels;

namespace UserInfo.Models.AuthendicationModels
{
    public class LoginModel : LoginBase
    {

    }
}