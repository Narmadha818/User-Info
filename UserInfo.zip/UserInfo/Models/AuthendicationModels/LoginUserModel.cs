﻿using UserInfo.Models.BaseModels;

namespace UserInfo.Models.AuthendicationModels
{
    public class LoginUserModel 
    {
        public LoginModel LoginProfile { get; set; }
        public UserModel UserProfile { get; set; }

    }
}