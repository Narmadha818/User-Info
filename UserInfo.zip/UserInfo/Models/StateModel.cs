﻿using UserInfo.Models.BaseModels;

namespace UserInfo.Models
{
    public class StateModel : StateBase
    {
        
    }
}