﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace UserInfo.Models.BaseModels
{
    public class UserBase : Auditable
   {  
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("firstname")]
        public string FirstName { get; set; }

        [Column("lastname")]
        public string LastName { get; set; }

        [Column("email")]
        public string Email { get; set; }

        [Column("phonenumber")]
        public string PhoneNumber { get; set; }

        [Column("address")]
        public string Address { get; set; }

        [Column("stateid")]
        public int StateId { get; set; }

        [Column("country")]
        public string Country { get; set; }

        [Column("postalcode")]
        public string PostalCode { get; set; }

        [JsonIgnore]
        [Column("isdeleted")]
        public bool IsDeleted { get; set; }
    }
}