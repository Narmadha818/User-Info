﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace UserInfo.Models.BaseModels
{
    public abstract class Auditable
    {
        [Column("createddate")]
        [JsonIgnore]
        public DateTime CreatedDateTime { get; set; }

        [Column("createdby")]
        [JsonIgnore]
        public string? CreatedBy { get; set; }

        [Column("updateddate")]
        [JsonIgnore]
        public DateTime UpdatedDateTime { get; set; }

        [Column("updatedby")]
        [JsonIgnore]
        public string? UpdatedBy { get; set; }
    }
}
